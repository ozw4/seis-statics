from __future__ import annotations

import json
from dataclasses import replace
from typing import Any

import numpy as np
import pytest
from scipy import sparse

from seis_statics.time_term import (
    TimeTermDesignMatrix,
    TimeTermSparseSolverOptions,
    build_time_term_solver_system,
    solve_time_term_sparse_least_squares,
    summarize_time_term_sparse_solver_result,
)
from seis_statics.time_term.sparse_solver import (
    _ValidatedTimeTermDesign,
    _build_trace_prediction_valid_mask,
)

TRUE_NODE_TIME_TERM_S = np.asarray([0.010, -0.002, 0.006], dtype=np.float64)
SOURCE_NODE_ID_SORTED = np.asarray([0, 0, 1, 2, 1], dtype=np.int64)
RECEIVER_NODE_ID_SORTED = np.asarray([1, 2, 2, 2, 1], dtype=np.int64)
ROW_SOURCE_NODE_ID = SOURCE_NODE_ID_SORTED[:4].copy()
ROW_RECEIVER_NODE_ID = RECEIVER_NODE_ID_SORTED[:4].copy()
DATA_S = np.asarray([0.008, 0.016, 0.004, 0.012], dtype=np.float64)
OBSERVATION_MATRIX = sparse.csr_matrix(
    [
        [1.0, 1.0, 0.0],
        [1.0, 0.0, 1.0],
        [0.0, 1.0, 1.0],
        [0.0, 0.0, 2.0],
    ],
    dtype=np.float64,
)


def _design(**overrides: Any) -> TimeTermDesignMatrix:
    payload: dict[str, Any] = {
        'matrix': OBSERVATION_MATRIX.copy(),
        'data_s': DATA_S.copy(),
        'n_traces': 5,
        'n_observations': 4,
        'n_nodes': 3,
        'used_trace_mask_sorted': np.asarray([True, True, True, True, False]),
        'row_trace_index_sorted': np.arange(4, dtype=np.int64),
        'trace_to_row_index_sorted': np.asarray([0, 1, 2, 3, -1], dtype=np.int64),
        'source_node_id_sorted': SOURCE_NODE_ID_SORTED.copy(),
        'receiver_node_id_sorted': RECEIVER_NODE_ID_SORTED.copy(),
        'row_source_node_id': ROW_SOURCE_NODE_ID.copy(),
        'row_receiver_node_id': ROW_RECEIVER_NODE_ID.copy(),
        'row_pick_time_after_static_s': DATA_S.copy(),
        'row_moveout_time_s': np.zeros(4, dtype=np.float64),
        'row_data_s': DATA_S.copy(),
        'source_observation_count_by_node': np.asarray([2, 1, 1], dtype=np.int64),
        'receiver_observation_count_by_node': np.asarray([0, 1, 3], dtype=np.int64),
        'total_observation_count_by_node': np.asarray([2, 2, 4], dtype=np.int64),
    }
    payload.update(overrides)
    return TimeTermDesignMatrix(**payload)


def _disconnected_design() -> TimeTermDesignMatrix:
    matrix = sparse.csr_matrix(
        [
            [1.0, 1.0, 0.0, 0.0],
            [0.0, 0.0, 1.0, 1.0],
        ],
        dtype=np.float64,
    )
    return _design(
        matrix=matrix,
        data_s=np.asarray([0.1, 0.2], dtype=np.float64),
        n_traces=2,
        n_observations=2,
        n_nodes=4,
        used_trace_mask_sorted=np.asarray([True, True]),
        row_trace_index_sorted=np.asarray([0, 1], dtype=np.int64),
        trace_to_row_index_sorted=np.asarray([0, 1], dtype=np.int64),
        source_node_id_sorted=np.asarray([0, 2], dtype=np.int64),
        receiver_node_id_sorted=np.asarray([1, 3], dtype=np.int64),
        row_source_node_id=np.asarray([0, 2], dtype=np.int64),
        row_receiver_node_id=np.asarray([1, 3], dtype=np.int64),
        row_pick_time_after_static_s=np.asarray([0.1, 0.2], dtype=np.float64),
        row_moveout_time_s=np.zeros(2, dtype=np.float64),
        row_data_s=np.asarray([0.1, 0.2], dtype=np.float64),
        source_observation_count_by_node=np.asarray([1, 0, 1, 0], dtype=np.int64),
        receiver_observation_count_by_node=np.asarray([0, 1, 0, 1], dtype=np.int64),
        total_observation_count_by_node=np.asarray([1, 1, 1, 1], dtype=np.int64),
    )


def _one_edge_design() -> TimeTermDesignMatrix:
    matrix = sparse.csr_matrix([[1.0, 1.0]], dtype=np.float64)
    return _design(
        matrix=matrix,
        data_s=np.asarray([1.0], dtype=np.float64),
        n_traces=1,
        n_observations=1,
        n_nodes=2,
        used_trace_mask_sorted=np.asarray([True]),
        row_trace_index_sorted=np.asarray([0], dtype=np.int64),
        trace_to_row_index_sorted=np.asarray([0], dtype=np.int64),
        source_node_id_sorted=np.asarray([0], dtype=np.int64),
        receiver_node_id_sorted=np.asarray([1], dtype=np.int64),
        row_source_node_id=np.asarray([0], dtype=np.int64),
        row_receiver_node_id=np.asarray([1], dtype=np.int64),
        row_pick_time_after_static_s=np.asarray([1.0], dtype=np.float64),
        row_moveout_time_s=np.zeros(1, dtype=np.float64),
        row_data_s=np.asarray([1.0], dtype=np.float64),
        source_observation_count_by_node=np.asarray([1, 0], dtype=np.int64),
        receiver_observation_count_by_node=np.asarray([0, 1], dtype=np.int64),
        total_observation_count_by_node=np.asarray([1, 1], dtype=np.int64),
    )


def _unobserved_node_design() -> TimeTermDesignMatrix:
    matrix = sparse.hstack(
        [OBSERVATION_MATRIX, sparse.csr_matrix((4, 1), dtype=np.float64)],
        format='csr',
    )
    return _design(
        matrix=matrix,
        n_nodes=4,
        source_node_id_sorted=np.asarray([0, 0, 1, 2, 3], dtype=np.int64),
        receiver_node_id_sorted=np.asarray([1, 2, 2, 2, 3], dtype=np.int64),
        source_observation_count_by_node=np.asarray([2, 1, 1, 0], dtype=np.int64),
        receiver_observation_count_by_node=np.asarray([0, 1, 3, 0], dtype=np.int64),
        total_observation_count_by_node=np.asarray([2, 2, 4, 0], dtype=np.int64),
    )


def _accurate_options(**overrides: Any) -> TimeTermSparseSolverOptions:
    payload: dict[str, Any] = {
        'damping_lambda': 1.0e-10,
        'gauge': 'none',
        'solver': 'lsmr',
        'atol': 1.0e-12,
        'btol': 1.0e-12,
        'conlim': 1.0e12,
        'maxiter': 1000,
    }
    payload.update(overrides)
    return TimeTermSparseSolverOptions(**payload)


def _node_sum_matrix(
    source_node_id: np.ndarray,
    receiver_node_id: np.ndarray,
    *,
    n_nodes: int,
) -> sparse.csr_matrix:
    n_observations = int(source_node_id.shape[0])
    row = np.repeat(np.arange(n_observations, dtype=np.int64), 2)
    col = np.empty(n_observations * 2, dtype=np.int64)
    col[0::2] = source_node_id
    col[1::2] = receiver_node_id
    data = np.ones(n_observations * 2, dtype=np.float64)
    matrix = sparse.coo_matrix(
        (data, (row, col)),
        shape=(n_observations, n_nodes),
        dtype=np.float64,
    ).tocsr()
    matrix.sum_duplicates()
    matrix.sort_indices()
    return matrix


def _time_term_objective(
    matrix: sparse.csr_matrix,
    data_s: np.ndarray,
    x: np.ndarray,
    *,
    damping_lambda: float,
    prior_s: np.ndarray,
) -> float:
    residual = matrix @ x - data_s
    damping_residual = x - prior_s
    return float(
        residual @ residual + damping_lambda * (damping_residual @ damping_residual)
    )


def _design_from_used_and_candidates(
    *,
    used_source_node_id: np.ndarray,
    used_receiver_node_id: np.ndarray,
    candidate_source_node_id: np.ndarray,
    candidate_receiver_node_id: np.ndarray,
    n_nodes: int,
    true_node_time_term_s: np.ndarray,
) -> TimeTermDesignMatrix:
    row_data = (
        true_node_time_term_s[used_source_node_id]
        + true_node_time_term_s[used_receiver_node_id]
    )
    source_node_id = np.concatenate([used_source_node_id, candidate_source_node_id])
    receiver_node_id = np.concatenate([used_receiver_node_id, candidate_receiver_node_id])
    n_observations = int(used_source_node_id.shape[0])
    n_traces = int(source_node_id.shape[0])
    used_mask = np.zeros(n_traces, dtype=bool)
    used_mask[:n_observations] = True
    trace_to_row = np.full(n_traces, -1, dtype=np.int64)
    trace_to_row[:n_observations] = np.arange(n_observations, dtype=np.int64)
    source_count = np.bincount(used_source_node_id, minlength=n_nodes).astype(np.int64)
    receiver_count = np.bincount(used_receiver_node_id, minlength=n_nodes).astype(
        np.int64
    )
    return TimeTermDesignMatrix(
        matrix=_node_sum_matrix(
            used_source_node_id,
            used_receiver_node_id,
            n_nodes=n_nodes,
        ),
        data_s=np.ascontiguousarray(row_data, dtype=np.float64),
        n_traces=n_traces,
        n_observations=n_observations,
        n_nodes=n_nodes,
        used_trace_mask_sorted=used_mask,
        row_trace_index_sorted=np.arange(n_observations, dtype=np.int64),
        trace_to_row_index_sorted=trace_to_row,
        source_node_id_sorted=np.ascontiguousarray(source_node_id, dtype=np.int64),
        receiver_node_id_sorted=np.ascontiguousarray(receiver_node_id, dtype=np.int64),
        row_source_node_id=np.ascontiguousarray(used_source_node_id, dtype=np.int64),
        row_receiver_node_id=np.ascontiguousarray(used_receiver_node_id, dtype=np.int64),
        row_pick_time_after_static_s=np.ascontiguousarray(row_data, dtype=np.float64),
        row_moveout_time_s=np.zeros(n_observations, dtype=np.float64),
        row_data_s=np.ascontiguousarray(row_data, dtype=np.float64),
        source_observation_count_by_node=source_count,
        receiver_observation_count_by_node=receiver_count,
        total_observation_count_by_node=np.ascontiguousarray(
            source_count + receiver_count,
            dtype=np.int64,
        ),
    )


def test_time_term_solver_system_contains_observation_damping_and_gauge_rows() -> None:
    system = build_time_term_solver_system(
        _design(),
        options=TimeTermSparseSolverOptions(
            damping_lambda=0.5,
            gauge='auto_component',
            gauge_weight=2.0,
        ),
    )

    assert sparse.isspmatrix_csr(system.augmented_matrix)
    assert system.n_observation_rows == 4
    assert system.n_damping_rows == 3
    assert system.n_gauge_rows == 0
    assert system.gauge_resolution == 'tikhonov_prior'
    assert system.n_augmented_rows == 7
    assert system.augmented_matrix.shape == (7, 3)
    np.testing.assert_allclose(
        system.augmented_matrix[:4].toarray(),
        OBSERVATION_MATRIX.toarray(),
    )
    np.testing.assert_allclose(system.augmented_data_s[:4], DATA_S)


def test_time_term_solver_system_adds_damping_identity_rows() -> None:
    system = build_time_term_solver_system(
        _design(),
        options=TimeTermSparseSolverOptions(damping_lambda=0.25, gauge='none'),
    )

    np.testing.assert_allclose(
        system.augmented_matrix[4:7].toarray(),
        np.eye(3, dtype=np.float64) * 0.5,
    )
    np.testing.assert_allclose(system.augmented_data_s[4:7], np.zeros(3))


def test_time_term_solver_system_uses_scalar_damping_prior() -> None:
    system = build_time_term_solver_system(
        _design(),
        options=TimeTermSparseSolverOptions(
            damping_lambda=0.5,
            damping_prior_s=0.02,
            gauge='none',
        ),
    )

    np.testing.assert_allclose(system.damping_prior_s, np.full(3, 0.02))
    np.testing.assert_allclose(
        system.augmented_data_s[4:7],
        np.full(3, np.sqrt(0.5) * 0.02),
    )


def test_time_term_solver_system_uses_array_damping_prior() -> None:
    prior = np.asarray([0.01, 0.02, 0.03], dtype=np.float64)

    system = build_time_term_solver_system(
        _design(),
        options=TimeTermSparseSolverOptions(
            damping_lambda=0.5,
            damping_prior_s=prior,
            gauge='none',
        ),
    )

    np.testing.assert_allclose(system.damping_prior_s, prior)
    np.testing.assert_allclose(system.augmented_data_s[4:7], np.sqrt(0.5) * prior)


def test_time_term_solver_damping_residual_matches_objective_penalty() -> None:
    prior = np.asarray([0.01, -0.02, 0.04], dtype=np.float64)
    parameter_vector = np.asarray([0.03, -0.01, -0.02], dtype=np.float64)
    damping_lambda = 0.25
    system = build_time_term_solver_system(
        _design(),
        options=TimeTermSparseSolverOptions(
            damping_lambda=damping_lambda,
            damping_prior_s=prior,
            gauge='none',
        ),
    )

    damping_slice = slice(
        system.n_observation_rows,
        system.n_observation_rows + system.n_damping_rows,
    )
    damping_residual = (
        system.augmented_matrix[damping_slice] @ parameter_vector
        - system.augmented_data_s[damping_slice]
    )

    assert system.n_damping_rows == system.n_nodes
    np.testing.assert_allclose(
        float(damping_residual @ damping_residual),
        damping_lambda * float(np.sum((parameter_vector - prior) ** 2)),
    )


def test_time_term_solver_positive_damping_prior_that_fits_observation_is_unchanged() -> None:
    result = solve_time_term_sparse_least_squares(
        _one_edge_design(),
        options=TimeTermSparseSolverOptions(
            damping_lambda=0.01,
            damping_prior_s=np.asarray([1.0, 0.0], dtype=np.float64),
            gauge='auto_component',
            max_abs_node_time_term_ms=None,
            max_abs_estimated_trace_delay_ms=None,
        ),
    )

    assert result.system.n_gauge_rows == 0
    assert result.system.gauge_resolution == 'tikhonov_prior'
    np.testing.assert_allclose(
        result.node_time_term_s,
        np.asarray([1.0, 0.0], dtype=np.float64),
        atol=1.0e-12,
    )


@pytest.mark.parametrize(
    'prior',
    [
        0.015,
        np.asarray([0.01, -0.02, 0.04], dtype=np.float64),
    ],
)
def test_time_term_sparse_solver_matches_closed_form_ridge_solution(
    prior: float | np.ndarray,
) -> None:
    design = _design()
    damping_lambda = 0.25
    prior_vector = (
        np.full(design.n_nodes, prior, dtype=np.float64)
        if np.asarray(prior).ndim == 0
        else np.asarray(prior, dtype=np.float64)
    )
    result = solve_time_term_sparse_least_squares(
        design,
        options=TimeTermSparseSolverOptions(
            damping_lambda=damping_lambda,
            damping_prior_s=prior,
            gauge='auto_component',
            solver='lsmr',
            atol=1.0e-12,
            btol=1.0e-12,
            conlim=1.0e12,
            maxiter=1000,
            max_abs_node_time_term_ms=None,
            max_abs_estimated_trace_delay_ms=None,
        ),
    )
    matrix = design.matrix.toarray()
    expected = np.linalg.solve(
        matrix.T @ matrix + damping_lambda * np.eye(design.n_nodes),
        matrix.T @ design.data_s + damping_lambda * prior_vector,
    )

    assert result.system.n_gauge_rows == 0
    assert result.system.gauge_resolution == 'tikhonov_prior'
    np.testing.assert_allclose(result.node_time_term_s, expected, atol=1.0e-12)


def test_time_term_sparse_solver_positive_damping_is_gauge_mode_invariant() -> None:
    design = _one_edge_design()
    damping_lambda = 0.01
    prior = np.asarray([1.0, 0.0], dtype=np.float64)
    auto_result = solve_time_term_sparse_least_squares(
        design,
        options=TimeTermSparseSolverOptions(
            damping_lambda=damping_lambda,
            damping_prior_s=prior,
            gauge='auto_component',
            gauge_weight=-1.0,
            max_abs_node_time_term_ms=None,
            max_abs_estimated_trace_delay_ms=None,
        ),
    )
    none_result = solve_time_term_sparse_least_squares(
        design,
        options=TimeTermSparseSolverOptions(
            damping_lambda=damping_lambda,
            damping_prior_s=prior,
            gauge='none',
            gauge_weight=-1.0,
            max_abs_node_time_term_ms=None,
            max_abs_estimated_trace_delay_ms=None,
        ),
    )

    assert auto_result.system.n_gauge_rows == 0
    assert none_result.system.n_gauge_rows == 0
    assert auto_result.system.gauge_resolution == 'tikhonov_prior'
    assert none_result.system.gauge_resolution == 'tikhonov_prior'
    np.testing.assert_allclose(auto_result.node_time_term_s, none_result.node_time_term_s)
    np.testing.assert_allclose(
        _time_term_objective(
            design.matrix,
            design.data_s,
            auto_result.node_time_term_s,
            damping_lambda=damping_lambda,
            prior_s=prior,
        ),
        _time_term_objective(
            design.matrix,
            design.data_s,
            none_result.node_time_term_s,
            damping_lambda=damping_lambda,
            prior_s=prior,
        ),
    )


def test_time_term_solver_system_adds_auto_component_signed_gauge_rows() -> None:
    system = build_time_term_solver_system(
        _disconnected_design(),
        options=TimeTermSparseSolverOptions(
            damping_lambda=0.0,
            gauge='auto_component',
            gauge_weight=2.0,
        ),
    )

    assert system.n_damping_rows == 0
    assert system.n_gauge_rows == 2
    assert system.gauge_resolution == 'component_signed_rows'
    np.testing.assert_allclose(
        system.augmented_matrix[-2:].toarray(),
        [
            [2.0 / np.sqrt(2.0), -2.0 / np.sqrt(2.0), 0.0, 0.0],
            [0.0, 0.0, 2.0 / np.sqrt(2.0), -2.0 / np.sqrt(2.0)],
        ],
    )
    np.testing.assert_allclose(system.augmented_data_s[-2:], 0.0)


def test_time_term_solver_system_skips_auto_component_gauge_for_nonbipartite_graph() -> None:
    system = build_time_term_solver_system(
        _design(),
        options=TimeTermSparseSolverOptions(
            damping_lambda=0.0,
            gauge='auto_component',
            gauge_weight=0.0,
        ),
    )

    assert system.n_gauge_rows == 0
    assert system.gauge_resolution == 'already_full_rank'
    assert system.n_bipartite_components == 0


def test_time_term_solver_system_none_zero_damping_allows_nonbipartite_graph() -> None:
    system = build_time_term_solver_system(
        _design(),
        options=TimeTermSparseSolverOptions(
            damping_lambda=0.0,
            gauge='none',
        ),
    )

    assert system.n_gauge_rows == 0
    assert system.gauge_resolution == 'already_full_rank'
    assert system.n_bipartite_components == 0


def test_time_term_sparse_solver_zero_damping_auto_gauge_preserves_observation() -> None:
    result = solve_time_term_sparse_least_squares(
        _one_edge_design(),
        options=TimeTermSparseSolverOptions(
            damping_lambda=0.0,
            gauge='auto_component',
            gauge_weight=2.0,
            solver='lsmr',
            atol=1.0e-12,
            btol=1.0e-12,
            conlim=1.0e12,
            maxiter=1000,
            max_abs_node_time_term_ms=None,
            max_abs_estimated_trace_delay_ms=None,
        ),
    )

    assert result.system.n_damping_rows == 0
    assert result.system.n_gauge_rows == 1
    assert result.system.gauge_resolution == 'component_signed_rows'
    np.testing.assert_allclose(result.row_estimated_time_term_delay_s, [1.0])
    np.testing.assert_allclose(result.row_residual_after_s, [0.0], atol=1.0e-12)


def test_time_term_solver_system_rejects_none_zero_damping_for_bipartite_graph() -> None:
    with pytest.raises(ValueError, match='zero damping'):
        build_time_term_solver_system(
            _disconnected_design(),
            options=TimeTermSparseSolverOptions(damping_lambda=0.0, gauge='none'),
        )


@pytest.mark.parametrize('gauge', ['mean_zero', 'component_mean_zero', 'reference_node'])
def test_time_term_solver_system_rejects_legacy_gauge_modes(gauge: str) -> None:
    with pytest.raises(ValueError, match='unsupported gauge'):
        build_time_term_solver_system(
            _design(),
            options=TimeTermSparseSolverOptions(gauge=gauge),  # type: ignore[arg-type]
        )


def test_time_term_solver_system_rejects_unobserved_node_when_required() -> None:
    with pytest.raises(ValueError, match='all nodes'):
        build_time_term_solver_system(_unobserved_node_design())


def test_time_term_solver_system_allows_unobserved_node_when_configured() -> None:
    system = build_time_term_solver_system(
        _unobserved_node_design(),
        options=TimeTermSparseSolverOptions(
            damping_lambda=0.01,
            gauge='auto_component',
            require_all_nodes_observed=False,
            min_total_observations_per_node=0,
        ),
    )

    assert system.n_components == 2
    np.testing.assert_array_equal(system.component_id_by_node, [0, 0, 0, 1])


@pytest.mark.parametrize('solver', ['lsmr', 'lsqr'])
def test_time_term_sparse_solver_recovers_known_node_time_terms(
    solver: str,
) -> None:
    result = solve_time_term_sparse_least_squares(
        _design(),
        options=_accurate_options(solver=solver),
    )

    np.testing.assert_allclose(
        result.node_time_term_s,
        TRUE_NODE_TIME_TERM_S,
        atol=1.0e-9,
    )
    np.testing.assert_allclose(
        OBSERVATION_MATRIX @ result.node_time_term_s,
        DATA_S,
        atol=1.0e-9,
    )


def test_time_term_sparse_solver_reduces_rms_residual() -> None:
    result = solve_time_term_sparse_least_squares(
        _design(),
        options=_accurate_options(),
    )

    assert result.rms_residual_after_s < result.rms_residual_before_s
    assert result.rms_residual_after_s < 1.0e-9


def test_time_term_sparse_solver_returns_row_residuals_in_observation_order() -> None:
    result = solve_time_term_sparse_least_squares(
        _design(),
        options=_accurate_options(),
    )

    np.testing.assert_allclose(result.row_residual_before_s, DATA_S)
    np.testing.assert_allclose(result.row_residual_after_s, np.zeros(4), atol=1.0e-9)
    np.testing.assert_array_equal(result.row_trace_index_sorted, [0, 1, 2, 3])


def test_time_term_sparse_solver_returns_estimated_trace_delay_in_sorted_order() -> None:
    result = solve_time_term_sparse_least_squares(
        _design(),
        options=_accurate_options(),
    )

    expected = (
        TRUE_NODE_TIME_TERM_S[SOURCE_NODE_ID_SORTED]
        + TRUE_NODE_TIME_TERM_S[RECEIVER_NODE_ID_SORTED]
    )
    np.testing.assert_allclose(
        result.estimated_trace_time_term_delay_s_sorted,
        expected,
        atol=1.0e-9,
        equal_nan=True,
    )
    np.testing.assert_array_equal(
        result.prediction_valid_trace_mask_sorted,
        [True, True, True, True, True],
    )
    assert result.used_trace_mask_sorted[4].item() is False
    assert np.isfinite(result.estimated_trace_time_term_delay_s_sorted[4])


def test_time_term_sparse_solver_fit_used_only_prediction_policy_limits_delay() -> None:
    result = solve_time_term_sparse_least_squares(
        _design(),
        options=_accurate_options(trace_prediction_policy='fit_used_only'),
    )
    summary = summarize_time_term_sparse_solver_result(result)

    np.testing.assert_array_equal(
        result.prediction_valid_trace_mask_sorted,
        result.used_trace_mask_sorted,
    )
    assert np.isnan(result.estimated_trace_time_term_delay_s_sorted[4])
    assert summary['n_prediction_valid_traces'] == 4
    assert summary['n_fit_unused_prediction_valid_traces'] == 0
    assert summary['n_unsupported_endpoint_traces'] == 0


def test_fit_used_only_prediction_policy_uses_final_fit_mask_exactly() -> None:
    design = _ValidatedTimeTermDesign(
        matrix=sparse.csr_matrix((2, 3), dtype=np.float64),
        data_s=np.zeros(2, dtype=np.float64),
        n_traces=3,
        n_observations=2,
        n_nodes=3,
        used_trace_mask_sorted=np.asarray([True, True, False]),
        row_trace_index_sorted=np.asarray([0, 1], dtype=np.int64),
        row_source_node_id=np.asarray([0, 1], dtype=np.int64),
        row_receiver_node_id=np.asarray([1, 2], dtype=np.int64),
        source_node_id_sorted=np.asarray([0, 1, 2], dtype=np.int64),
        receiver_node_id_sorted=np.asarray([1, 2, 0], dtype=np.int64),
        total_observation_count_by_node=np.asarray([1, 1, 1], dtype=np.int64),
    )

    fit_used_mask = _build_trace_prediction_valid_mask(
        design,
        options=TimeTermSparseSolverOptions(
            min_total_observations_per_node=2,
            trace_prediction_policy='fit_used_only',
        ),
    )
    all_supported_mask = _build_trace_prediction_valid_mask(
        design,
        options=TimeTermSparseSolverOptions(
            min_total_observations_per_node=2,
            trace_prediction_policy='all_supported',
        ),
    )

    np.testing.assert_array_equal(fit_used_mask, [True, True, False])
    np.testing.assert_array_equal(all_supported_mask, [False, False, False])


def test_time_term_sparse_solver_unsupported_endpoint_prediction_stays_nan() -> None:
    result = solve_time_term_sparse_least_squares(
        _unobserved_node_design(),
        options=_accurate_options(
            damping_lambda=0.01,
            gauge='auto_component',
            require_all_nodes_observed=False,
            min_total_observations_per_node=0,
        ),
    )

    np.testing.assert_array_equal(
        result.prediction_valid_trace_mask_sorted,
        [True, True, True, True, False],
    )
    assert np.isnan(result.estimated_trace_time_term_delay_s_sorted[4])


def test_time_term_sparse_solver_invalidates_cross_component_bipartite_prediction() -> None:
    design = _design_from_used_and_candidates(
        used_source_node_id=np.asarray([0, 2], dtype=np.int64),
        used_receiver_node_id=np.asarray([1, 3], dtype=np.int64),
        candidate_source_node_id=np.asarray([0], dtype=np.int64),
        candidate_receiver_node_id=np.asarray([3], dtype=np.int64),
        n_nodes=4,
        true_node_time_term_s=np.asarray([0.01, 0.02, 0.03, 0.04], dtype=np.float64),
    )

    result = solve_time_term_sparse_least_squares(
        design,
        options=_accurate_options(
            damping_lambda=0.01,
            gauge='auto_component',
        ),
    )
    summary = summarize_time_term_sparse_solver_result(result)

    np.testing.assert_array_equal(
        result.prediction_valid_trace_mask_sorted,
        [True, True, False],
    )
    assert np.isnan(result.estimated_trace_time_term_delay_s_sorted[2])
    assert summary['n_endpoint_supported_traces'] == 3
    assert summary['n_prediction_identifiable_traces'] == 2
    assert (
        summary['n_endpoint_supported_prediction_invalid_due_to_gauge_traces'] == 1
    )
    assert summary['n_unsupported_endpoint_traces'] == 0


def test_time_term_sparse_solver_allows_cross_component_nonbipartite_prediction() -> None:
    design = _design_from_used_and_candidates(
        used_source_node_id=np.asarray([0, 1, 2, 3, 4, 5], dtype=np.int64),
        used_receiver_node_id=np.asarray([1, 2, 0, 4, 5, 3], dtype=np.int64),
        candidate_source_node_id=np.asarray([0], dtype=np.int64),
        candidate_receiver_node_id=np.asarray([3], dtype=np.int64),
        n_nodes=6,
        true_node_time_term_s=np.asarray(
            [0.01, 0.02, 0.03, -0.01, -0.02, -0.03],
            dtype=np.float64,
        ),
    )

    result = solve_time_term_sparse_least_squares(
        design,
        options=_accurate_options(
            damping_lambda=0.0,
            gauge='none',
        ),
    )
    summary = summarize_time_term_sparse_solver_result(result)

    np.testing.assert_array_equal(
        result.prediction_valid_trace_mask_sorted,
        [True, True, True, True, True, True, True],
    )
    assert np.isfinite(result.estimated_trace_time_term_delay_s_sorted[6])
    assert summary['n_endpoint_supported_traces'] == 7
    assert summary['n_prediction_identifiable_traces'] == 7
    assert (
        summary['n_endpoint_supported_prediction_invalid_due_to_gauge_traces'] == 0
    )


def test_time_term_sparse_solver_same_source_receiver_node_uses_two_times_node_term() -> None:
    result = solve_time_term_sparse_least_squares(
        _design(),
        options=_accurate_options(),
    )

    assert result.row_estimated_time_term_delay_s[3] == pytest.approx(
        2.0 * result.node_time_term_s[2],
        abs=1.0e-12,
    )


def test_time_term_sparse_solver_rejects_non_finite_data_vector() -> None:
    data = DATA_S.copy()
    data[0] = np.nan

    with pytest.raises(ValueError, match='data_s'):
        build_time_term_solver_system(_design(data_s=data))


def test_time_term_sparse_solver_rejects_node_time_term_above_limit() -> None:
    with pytest.raises(ValueError, match='max_abs_node_time_term_ms'):
        solve_time_term_sparse_least_squares(
            _design(),
            options=_accurate_options(max_abs_node_time_term_ms=5.0),
        )


def test_time_term_sparse_solver_rejects_estimated_trace_delay_above_limit() -> None:
    with pytest.raises(ValueError, match='max_abs_estimated_trace_delay_ms'):
        solve_time_term_sparse_least_squares(
            _design(),
            options=_accurate_options(
                max_abs_node_time_term_ms=None,
                max_abs_estimated_trace_delay_ms=5.0,
            ),
        )


def test_time_term_sparse_solver_result_does_not_expose_applied_shift() -> None:
    result = solve_time_term_sparse_least_squares(
        _design(),
        options=_accurate_options(),
    )

    assert not hasattr(result, 'applied_weathering_shift_s')
    assert not hasattr(result, 'applied_trace_time_term_shift_s_sorted')


def test_summarize_time_term_sparse_solver_result_is_json_safe() -> None:
    result = solve_time_term_sparse_least_squares(
        _design(),
        options=_accurate_options(),
    )

    summary = summarize_time_term_sparse_solver_result(result)

    json.dumps(summary, allow_nan=False)
    assert summary['n_nodes'] == 3
    assert summary['n_observations'] == 4
    assert summary['n_damping_rows'] == 3
    assert summary['n_gauge_rows'] == 0
    assert summary['gauge_mode'] == 'none'
    assert summary['gauge_resolution'] == 'tikhonov_prior'
    assert summary['solver_name'] == 'lsmr'
    assert summary['n_unobserved_nodes'] == 0
    assert summary['n_fit_used_traces'] == 4
    assert summary['n_robust_rejected_traces'] == 0
    assert summary['n_endpoint_supported_traces'] == 5
    assert summary['n_prediction_identifiable_traces'] == 5
    assert summary['n_endpoint_supported_prediction_invalid_due_to_gauge_traces'] == 0
    assert summary['n_prediction_valid_traces'] == 5
    assert summary['n_fit_unused_prediction_valid_traces'] == 1
    assert summary['n_unsupported_endpoint_traces'] == 0
    assert summary['node_time_term_ms']['count'] == 3


def test_time_term_sparse_solver_rejects_nonfinite_solver_output(monkeypatch) -> None:
    class BadLsmr:
        def __call__(self, *args: Any, **kwargs: Any):
            return (
                np.asarray([np.nan, 0.0, 0.0], dtype=np.float64),
                1,
                1,
                0.0,
                0.0,
                1.0,
                1.0,
                0.0,
            )

    import seis_statics.time_term.sparse_solver as solver_module

    monkeypatch.setattr(solver_module.sparse_linalg, 'lsmr', BadLsmr())

    with pytest.raises(ValueError, match='solver x'):
        solve_time_term_sparse_least_squares(
            _design(),
            options=_accurate_options(),
        )


def test_time_term_sparse_solver_rejects_damping_prior_shape_mismatch() -> None:
    with pytest.raises(ValueError, match='damping_prior_s'):
        build_time_term_solver_system(
            _design(),
            options=TimeTermSparseSolverOptions(
                damping_prior_s=np.asarray([0.0, 0.0]),
            ),
        )


def test_time_term_sparse_solver_rejects_min_observation_violation() -> None:
    with pytest.raises(ValueError, match='not enough'):
        build_time_term_solver_system(
            _design(),
            options=TimeTermSparseSolverOptions(min_observations=5),
        )


def test_time_term_sparse_solver_rejects_node_below_min_total_observations() -> None:
    with pytest.raises(ValueError, match='min_total_observations_per_node'):
        build_time_term_solver_system(
            _design(),
            options=TimeTermSparseSolverOptions(min_total_observations_per_node=3),
        )


def test_time_term_sparse_solver_validates_design_total_count_consistency() -> None:
    bad_design = replace(
        _design(),
        total_observation_count_by_node=np.asarray([2, 2, 3], dtype=np.int64),
    )

    with pytest.raises(ValueError, match='total_observation_count_by_node'):
        build_time_term_solver_system(bad_design)
