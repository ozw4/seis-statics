"""Lightweight refraction statics types, options, and status helpers."""

from __future__ import annotations

from seis_statics.refraction.cell_velocity_status import (
    LOW_FOLD_CELL_REJECTION_REASON,
    LOW_FOLD_CELL_VELOCITY_STATUS,
)
from seis_statics.refraction.cell_coordinates import (
    RefractionCellCoordinateMode,
    RefractionCellProjectedPoints,
    RefractionCellProjectedSourceReceiver,
    effective_refraction_cell_grid_config,
    project_refraction_cell_coordinates,
    project_refraction_cell_points,
    refraction_cell_coordinate_metadata,
    refraction_cell_coordinate_metadata_from_config,
)
from seis_statics.refraction.cell_grid import (
    RefractionCellAssignment,
    RefractionCellGrid,
    assign_observation_midpoint_cells,
    assign_points_to_refraction_cells,
    build_refraction_cell_grid,
    compute_source_receiver_midpoints,
)
from seis_statics.refraction.first_layer import (
    normalize_refraction_first_layer_request,
    resolve_weathering_velocity_m_s,
    resolved_first_layer_weathering_velocity_m_s,
    validate_resolved_first_layer_velocity_match,
)
from seis_statics.refraction.field_composition import (
    RefractionFieldComposedTraceShiftResult,
    RefractionFieldCompositionError,
    RefractionFieldInvalidComponentPolicy,
    compose_refraction_endpoint_field_corrections,
    compose_refraction_final_trace_shift,
    compose_refraction_trace_field_corrections,
)
from seis_statics.refraction.layer_config import (
    RefractionLayerConfig,
    RefractionLayerConfigLayer,
    layer_offset_gate_contains,
    normalize_refraction_layer_config,
)
from seis_statics.refraction.layer_observations import (
    ALREADY_ASSIGNED_REJECTION_REASON,
    INVALID_OBSERVATION_REJECTION_REASON,
    INVALID_OFFSET_REJECTION_REASON,
    OK_REJECTION_REASON,
    OUTSIDE_LAYER_GATE_REJECTION_REASON,
    build_refraction_layer_observation_masks,
    refraction_layer_observation_qc,
)
from seis_statics.refraction.manual_static import (
    ManualStaticSignConvention,
    RefractionManualStaticTableRow,
    manual_static_inline_rows,
    normalize_refraction_manual_static_rows,
    resolve_refraction_manual_static,
)
from seis_statics.refraction.options import (
    RefractionStaticConversionMode,
    RefractionStaticConversionOptions,
    RefractionStaticDatumMode,
    RefractionStaticDatumOptions,
    RefractionStaticDatumSmoothingMethod,
    RefractionStaticDistanceSource,
    RefractionStaticFirstLayerOptions,
    RefractionStaticFloatingDatumMode,
    RefractionStaticLayerAssignmentPolicy,
    RefractionStaticLayerKind,
    RefractionStaticLayerOptions,
    RefractionStaticLayerVelocityMode,
    RefractionStaticMethod,
    RefractionStaticModelOptions,
    RefractionStaticMoveoutModel,
    RefractionStaticMoveoutOptions,
    RefractionStaticReducedTimeQcOptions,
    RefractionStaticReducedTimeQcVelocityMode,
    RefractionStaticRefractorCellAssignmentMode,
    RefractionStaticRefractorCellCoordinateMode,
    RefractionStaticRefractorCellOptions,
    RefractionStaticRefractorCellOutsideGridPolicy,
    RefractionStaticRobustMethod,
    RefractionStaticRobustOptions,
    RefractionStaticSolverOptions,
)
from seis_statics.refraction.status import (
    LOCAL_V2_STATUS_VALUES,
    REFRACTION_STATIC_STATUSES,
    classify_refraction_endpoint_static_status,
)
from seis_statics.refraction.t1lsst import (
    T1LSST_SIGN_CONVENTION,
    RefractionT1LSST1LayerEndpointComponents,
    RefractionT1LSST2LayerThicknessResult,
    RefractionT1LSST3LayerThicknessResult,
    RefractionT1LSSTError,
    compose_t1lsst_1layer_endpoint_component_rows,
    compute_t1lsst_1layer_thickness,
    compute_t1lsst_1layer_weathering_correction,
    compute_t1lsst_2layer_thicknesses,
    compute_t1lsst_2layer_thicknesses_with_status,
    compute_t1lsst_2layer_weathering_correction,
    compute_t1lsst_3layer_thicknesses,
    compute_t1lsst_3layer_thicknesses_with_status,
    compute_t1lsst_3layer_weathering_correction,
)
from seis_statics.refraction.source_depth import (
    compute_source_depth_weathering_time_correction,
    compute_source_depth_weathering_time_correction_from_result,
    resolve_refraction_source_depth,
    resolve_refraction_source_depth_for_input_model,
)
from seis_statics.refraction.types import (
    REFRACTION_FIELD_CORRECTION_COMPONENT_NAMES,
    BedrockVelocityMode,
    RefractionEndpointTable,
    RefractionEndpointFieldCorrectionResult,
    RefractionFieldCorrectionComponentName,
    RefractionFirstLayerMode,
    RefractionLayerAssignmentPolicy,
    RefractionLayerKind,
    RefractionLayerObservationMasks,
    RefractionLayerVelocityMode,
    RefractionManualStaticResult,
    RefractionSourceDepthMode,
    RefractionSourceDepthResult,
    RefractionSourceDepthStatus,
    RefractionStaticInputModel,
    RefractionTraceFieldCorrectionResult,
    RefractionUpholeResult,
    RefractionUpholeStatus,
    RefractionV1EstimateResult,
    ResolvedRefractionFirstLayer,
)
from seis_statics.refraction.uphole import (
    compute_uphole_time_correction,
    compute_uphole_time_correction_from_result,
    resolve_refraction_uphole,
    resolve_refraction_uphole_for_input_model,
)
from seis_statics.refraction.v1 import (
    RefractionV1EstimationError,
    estimate_global_v1_from_direct_arrivals,
)

_DESIGN_MATRIX_EXPORTS = frozenset(
    {
        'LOW_FOLD_NODE_REJECTION_REASON',
        'LOW_FOLD_NODE_STATUS',
        'OUTSIDE_REFRACTOR_CELL_GRID_REASON',
        'RefractionDesignMatrixNodeDiagnostics',
        'RefractionStaticDesignMatrix',
        'RefractionStaticDesignMatrixError',
        'build_refraction_design_matrix_node_diagnostics',
        'build_refraction_static_cell_design_matrix',
        'build_refraction_static_design_matrix',
        'build_refraction_static_design_matrix_from_arrays',
        'summarize_refraction_static_design_matrix',
    }
)
_SOLVER_EXPORTS = frozenset(
    {
        'RefractionStaticRobustIterationSummary',
        'RefractionStaticRobustStopReason',
        'RefractionStaticSolveResult',
        'RefractionStaticSolveSystem',
        'RefractionStaticSolverError',
        'build_refraction_static_solver_system',
        'solve_refraction_static_design_least_squares',
        'solve_refraction_static_least_squares',
        'summarize_refraction_static_solve_result',
        'validate_refraction_static_solver_options',
    }
)
_BEDROCK_EXPORTS = frozenset(
    {
        'GlobalBedrockSlownessEstimateResult',
        'RefractionBedrockEstimationError',
        'estimate_global_bedrock_slowness_from_input_model',
    }
)
_HALF_INTERCEPT_EXPORTS = frozenset(
    {
        'RefractionHalfInterceptEndpointResult',
        'RefractionHalfInterceptError',
        'RefractionHalfInterceptResult',
        'build_refraction_half_intercept_design',
        'build_refraction_half_intercept_result',
        'build_refraction_half_intercept_result_from_bedrock_result',
        'estimate_refraction_half_intercept_from_design',
        'estimate_refraction_half_intercept_from_input_model',
    }
)
_WEATHERING_EXPORTS = frozenset(
    {
        'RefractionWeatheringEndpointComponents',
        'RefractionWeatheringError',
        'RefractionWeatheringModel',
        'RefractionWeatheringThicknessComputation',
        'build_refraction_weathering_model_from_half_intercept_result',
        'compute_weathering_thickness_from_half_intercept_time',
        'compute_weathering_thickness_from_half_intercept_time_with_status',
        'compute_weathering_thickness_scalar_from_half_intercept_time',
    }
)
_WEATHERING_REPLACEMENT_EXPORTS = frozenset(
    {
        'RefractionWeatheringReplacementError',
        'RefractionWeatheringReplacementResult',
        'build_refraction_weathering_replacement_statics',
        'compute_weathering_replacement_shift_s',
        'compute_weathering_replacement_shift_scalar_s',
    }
)
_DATUM_EXPORTS = frozenset(
    {
        'RefractionDatumEndpointResult',
        'RefractionDatumError',
        'RefractionDatumStaticsResult',
        'ResolvedFloatingDatum',
        'build_refraction_datum_statics',
        'build_refraction_endpoint_datum_statics',
        'compute_refraction_datum_elevation_shift_s',
        'compute_refraction_datum_elevation_shift_scalar_s',
        'smooth_refraction_floating_datum_elevation',
    }
)
_MULTILAYER_SOLVER_EXPORTS = frozenset(
    {
        'ROBUST_REJECTION_REASON',
        'VELOCITY_ORDER_REJECTION_REASON',
        'RefractionMultilayerTimeTermLayerResult',
        'RefractionMultilayerTimeTermSolveResult',
        'RefractionMultilayerTimeTermSolverError',
        'solve_refraction_multilayer_time_terms',
    }
)
_MULTILAYER_CONVERSION_EXPORTS = frozenset(
    {
        'RefractionMultilayerConversionError',
        'RefractionMultilayerConversionResult',
        'RefractionMultilayerDatumStaticsResult',
        'RefractionMultilayerEndpointConversion',
        'build_refraction_multilayer_conversion',
        'compute_refraction_multilayer_datum_statics_from_input_model',
    }
)


def __getattr__(name: str) -> object:
    if name in _DESIGN_MATRIX_EXPORTS:
        from seis_statics.refraction import design_matrix

        value = getattr(design_matrix, name)
        globals()[name] = value
        return value
    if name in _SOLVER_EXPORTS:
        from seis_statics.refraction import solver

        value = getattr(solver, name)
        globals()[name] = value
        return value
    if name in _BEDROCK_EXPORTS:
        from seis_statics.refraction import bedrock

        value = getattr(bedrock, name)
        globals()[name] = value
        return value
    if name in _HALF_INTERCEPT_EXPORTS:
        from seis_statics.refraction import half_intercept

        value = getattr(half_intercept, name)
        globals()[name] = value
        return value
    if name in _WEATHERING_EXPORTS:
        from seis_statics.refraction import weathering

        value = getattr(weathering, name)
        globals()[name] = value
        return value
    if name in _WEATHERING_REPLACEMENT_EXPORTS:
        from seis_statics.refraction import weathering_replacement

        value = getattr(weathering_replacement, name)
        globals()[name] = value
        return value
    if name in _DATUM_EXPORTS:
        from seis_statics.refraction import datum

        value = getattr(datum, name)
        globals()[name] = value
        return value
    if name in _MULTILAYER_SOLVER_EXPORTS:
        from seis_statics.refraction import multilayer_solver

        value = getattr(multilayer_solver, name)
        globals()[name] = value
        return value
    if name in _MULTILAYER_CONVERSION_EXPORTS:
        from seis_statics.refraction import multilayer_conversion

        value = getattr(multilayer_conversion, name)
        globals()[name] = value
        return value
    raise AttributeError(f"module 'seis_statics.refraction' has no attribute {name!r}")


__all__ = [
    'BedrockVelocityMode',
    'ALREADY_ASSIGNED_REJECTION_REASON',
    'GlobalBedrockSlownessEstimateResult',
    'INVALID_OBSERVATION_REJECTION_REASON',
    'INVALID_OFFSET_REJECTION_REASON',
    'LOCAL_V2_STATUS_VALUES',
    'LOW_FOLD_CELL_REJECTION_REASON',
    'LOW_FOLD_CELL_VELOCITY_STATUS',
    'LOW_FOLD_NODE_REJECTION_REASON',
    'LOW_FOLD_NODE_STATUS',
    'ManualStaticSignConvention',
    'OK_REJECTION_REASON',
    'OUTSIDE_LAYER_GATE_REJECTION_REASON',
    'OUTSIDE_REFRACTOR_CELL_GRID_REASON',
    'REFRACTION_FIELD_CORRECTION_COMPONENT_NAMES',
    'REFRACTION_STATIC_STATUSES',
    'ROBUST_REJECTION_REASON',
    'RefractionCellAssignment',
    'RefractionCellCoordinateMode',
    'RefractionCellGrid',
    'RefractionCellProjectedPoints',
    'RefractionCellProjectedSourceReceiver',
    'RefractionBedrockEstimationError',
    'RefractionDesignMatrixNodeDiagnostics',
    'RefractionDatumEndpointResult',
    'RefractionDatumError',
    'RefractionDatumStaticsResult',
    'RefractionEndpointTable',
    'RefractionEndpointFieldCorrectionResult',
    'RefractionFieldCorrectionComponentName',
    'RefractionFieldComposedTraceShiftResult',
    'RefractionFieldCompositionError',
    'RefractionFieldInvalidComponentPolicy',
    'RefractionFirstLayerMode',
    'RefractionHalfInterceptEndpointResult',
    'RefractionHalfInterceptError',
    'RefractionHalfInterceptResult',
    'RefractionLayerAssignmentPolicy',
    'RefractionLayerConfig',
    'RefractionLayerConfigLayer',
    'RefractionLayerKind',
    'RefractionLayerObservationMasks',
    'RefractionLayerVelocityMode',
    'RefractionManualStaticResult',
    'RefractionMultilayerConversionError',
    'RefractionMultilayerConversionResult',
    'RefractionMultilayerDatumStaticsResult',
    'RefractionMultilayerEndpointConversion',
    'RefractionMultilayerTimeTermLayerResult',
    'RefractionMultilayerTimeTermSolveResult',
    'RefractionMultilayerTimeTermSolverError',
    'RefractionManualStaticTableRow',
    'RefractionSourceDepthMode',
    'RefractionSourceDepthResult',
    'RefractionSourceDepthStatus',
    'RefractionStaticConversionMode',
    'RefractionStaticConversionOptions',
    'RefractionStaticDatumMode',
    'RefractionStaticDatumOptions',
    'RefractionStaticDatumSmoothingMethod',
    'RefractionStaticDistanceSource',
    'RefractionStaticFirstLayerOptions',
    'RefractionStaticFloatingDatumMode',
    'RefractionStaticInputModel',
    'RefractionStaticDesignMatrix',
    'RefractionStaticDesignMatrixError',
    'RefractionTraceFieldCorrectionResult',
    'RefractionV1EstimateResult',
    'RefractionV1EstimationError',
    'RefractionWeatheringEndpointComponents',
    'RefractionWeatheringError',
    'RefractionWeatheringModel',
    'RefractionWeatheringReplacementError',
    'RefractionWeatheringReplacementResult',
    'RefractionWeatheringThicknessComputation',
    'RefractionStaticLayerKind',
    'RefractionStaticLayerAssignmentPolicy',
    'RefractionStaticLayerOptions',
    'RefractionStaticLayerVelocityMode',
    'RefractionStaticMethod',
    'RefractionStaticModelOptions',
    'RefractionStaticMoveoutModel',
    'RefractionStaticMoveoutOptions',
    'RefractionStaticReducedTimeQcOptions',
    'RefractionStaticReducedTimeQcVelocityMode',
    'RefractionStaticRefractorCellAssignmentMode',
    'RefractionStaticRefractorCellCoordinateMode',
    'RefractionStaticRefractorCellOptions',
    'RefractionStaticRefractorCellOutsideGridPolicy',
    'RefractionStaticRobustIterationSummary',
    'RefractionStaticRobustMethod',
    'RefractionStaticRobustOptions',
    'RefractionStaticRobustStopReason',
    'RefractionStaticSolveResult',
    'RefractionStaticSolveSystem',
    'RefractionStaticSolverOptions',
    'RefractionStaticSolverError',
    'RefractionT1LSST1LayerEndpointComponents',
    'RefractionT1LSST2LayerThicknessResult',
    'RefractionT1LSST3LayerThicknessResult',
    'RefractionT1LSSTError',
    'RefractionUpholeResult',
    'RefractionUpholeStatus',
    'ResolvedRefractionFirstLayer',
    'ResolvedFloatingDatum',
    'T1LSST_SIGN_CONVENTION',
    'VELOCITY_ORDER_REJECTION_REASON',
    'assign_observation_midpoint_cells',
    'assign_points_to_refraction_cells',
    'build_refraction_layer_observation_masks',
    'build_refraction_multilayer_conversion',
    'build_refraction_cell_grid',
    'build_refraction_datum_statics',
    'build_refraction_design_matrix_node_diagnostics',
    'build_refraction_endpoint_datum_statics',
    'build_refraction_half_intercept_design',
    'build_refraction_half_intercept_result',
    'build_refraction_half_intercept_result_from_bedrock_result',
    'build_refraction_static_cell_design_matrix',
    'build_refraction_static_design_matrix',
    'build_refraction_static_design_matrix_from_arrays',
    'build_refraction_static_solver_system',
    'build_refraction_weathering_model_from_half_intercept_result',
    'build_refraction_weathering_replacement_statics',
    'classify_refraction_endpoint_static_status',
    'compose_t1lsst_1layer_endpoint_component_rows',
    'compose_refraction_endpoint_field_corrections',
    'compose_refraction_final_trace_shift',
    'compose_refraction_trace_field_corrections',
    'compute_t1lsst_1layer_thickness',
    'compute_t1lsst_1layer_weathering_correction',
    'compute_t1lsst_2layer_thicknesses',
    'compute_t1lsst_2layer_thicknesses_with_status',
    'compute_t1lsst_2layer_weathering_correction',
    'compute_t1lsst_3layer_thicknesses',
    'compute_t1lsst_3layer_thicknesses_with_status',
    'compute_t1lsst_3layer_weathering_correction',
    'compute_refraction_datum_elevation_shift_s',
    'compute_refraction_datum_elevation_shift_scalar_s',
    'compute_refraction_multilayer_datum_statics_from_input_model',
    'compute_weathering_thickness_from_half_intercept_time',
    'compute_weathering_thickness_from_half_intercept_time_with_status',
    'compute_weathering_thickness_scalar_from_half_intercept_time',
    'compute_weathering_replacement_shift_s',
    'compute_weathering_replacement_shift_scalar_s',
    'compute_source_depth_weathering_time_correction',
    'compute_source_depth_weathering_time_correction_from_result',
    'compute_source_receiver_midpoints',
    'compute_uphole_time_correction',
    'compute_uphole_time_correction_from_result',
    'estimate_global_v1_from_direct_arrivals',
    'estimate_global_bedrock_slowness_from_input_model',
    'estimate_refraction_half_intercept_from_design',
    'estimate_refraction_half_intercept_from_input_model',
    'effective_refraction_cell_grid_config',
    'layer_offset_gate_contains',
    'manual_static_inline_rows',
    'normalize_refraction_first_layer_request',
    'normalize_refraction_layer_config',
    'normalize_refraction_manual_static_rows',
    'project_refraction_cell_coordinates',
    'project_refraction_cell_points',
    'refraction_cell_coordinate_metadata',
    'refraction_cell_coordinate_metadata_from_config',
    'refraction_layer_observation_qc',
    'resolve_weathering_velocity_m_s',
    'resolve_refraction_source_depth',
    'resolve_refraction_source_depth_for_input_model',
    'resolve_refraction_manual_static',
    'resolve_refraction_uphole',
    'resolve_refraction_uphole_for_input_model',
    'resolved_first_layer_weathering_velocity_m_s',
    'solve_refraction_static_design_least_squares',
    'solve_refraction_static_least_squares',
    'solve_refraction_multilayer_time_terms',
    'smooth_refraction_floating_datum_elevation',
    'summarize_refraction_static_design_matrix',
    'summarize_refraction_static_solve_result',
    'validate_refraction_static_solver_options',
    'validate_resolved_first_layer_velocity_match',
]
